# Balagan

R package focusing on spatial analysis of IMC data on a large scale. Will include spatial community analysis, as well as spatial point patterns tools.
